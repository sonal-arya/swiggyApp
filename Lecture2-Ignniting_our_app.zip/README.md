# Namaste react

# parcel
 - Dev build
 - local server
 - HMR - hot module replacement
 - file watching algorithm - written in c++
 -caching - faster builds
 - image optimization 
 - bundling
 - compressing
 - consistent hashing
 - differenetal bundling - to support older browers
 - diagnostic 
 - error handling
 - https
 - tree shaking - remove unused code 
 - diffreent dev and prod bundle 